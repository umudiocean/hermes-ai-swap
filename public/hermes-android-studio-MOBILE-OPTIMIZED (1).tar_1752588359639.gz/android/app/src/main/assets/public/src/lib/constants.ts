export const HERMES_CONTRACT_ADDRESS = "0x9495aB3549338BF14aD2F86CbcF79C7b574bba37";
export const HERMES_RESWAP_V2_ADDRESS = "0x4C7d75909f744D7e69EcDdaCD1840c9A26A4Aa00"; // HermesBogSwap3 - NEW contract with automatic fee collection
export const HERMES_SINGLE_TX_ADDRESS = "0x0000000000000000000000000000000000000000"; // Placeholder for legacy compatibility
export const REWARD_AMOUNT = "100000";
export const EXCHANGE_RATE = 2500; // 1 BNB = 2500 HERMES (this should come from an API in production)

export const TRADING_PAIRS = {
  BNB: {
    symbol: "BNB",
    name: "Binance Coin",
    decimals: 18,
    icon: "B",
    color: "bg-yellow-500",
  },
  HERMES: {
    symbol: "HERMES",
    name: "Hermes Token",
    decimals: 18,
    icon: "H",
    color: "bg-gradient-to-br from-[var(--hermes-gold)] to-yellow-500",
    address: HERMES_CONTRACT_ADDRESS,
  },
};

export const BSC_EXPLORER_URL = "https://bscscan.com";
