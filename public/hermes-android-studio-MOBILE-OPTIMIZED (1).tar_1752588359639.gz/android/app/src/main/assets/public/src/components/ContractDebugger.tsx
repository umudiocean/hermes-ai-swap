// ContractDebugger component removed by user request
export default function ContractDebugger() {
  return null;
}