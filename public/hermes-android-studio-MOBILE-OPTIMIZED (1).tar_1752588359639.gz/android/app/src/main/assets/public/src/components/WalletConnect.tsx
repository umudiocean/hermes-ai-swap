import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useWalletStore } from '@/stores/useWalletStore';
import { Wallet, LogOut, Copy, Check, Smartphone } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/hooks/useTranslation';
import { useWeb3ModalProvider, useWeb3ModalAccount, useWeb3Modal, useDisconnect } from '@web3modal/ethers/react';
import { BrowserProvider } from 'ethers';
import { isMobile, generateWalletDeepLink } from '@/lib/mobileWallet';

export default function WalletConnect() {
  // Web3Modal hooks
  const { address: web3Address, isConnected: web3Connected, chainId } = useWeb3ModalAccount();
  const { walletProvider } = useWeb3ModalProvider();
  const { open } = useWeb3Modal();
  const { disconnect } = useDisconnect();
  
  // Legacy store
  const { 
    isConnected, 
    address,
    walletAddress, 
    disconnectWallet,
    isConnecting,
    setWalletData
  } = useWalletStore();
  
  const { toast } = useToast();
  const { t } = useTranslation();
  const [copied, setCopied] = React.useState(false);
  const [localConnecting, setLocalConnecting] = React.useState(false);

  // Sync Web3Modal with store
  useEffect(() => {
    if (web3Connected && web3Address && walletProvider) {
      const syncWallet = async () => {
        try {
          const provider = new BrowserProvider(walletProvider);
          const signer = await provider.getSigner();
          setWalletData(provider, signer, web3Address, 'Web3Modal');
        } catch (error) {
          console.error('Wallet sync error:', error);
        }
      };
      syncWallet();
    }
  }, [web3Connected, web3Address, walletProvider, setWalletData]);

  // Switch to BSC if wrong network
  useEffect(() => {
    if (web3Connected && chainId !== 56) {
      switchToBSC();
    }
  }, [chainId, web3Connected]);

  const switchToBSC = async () => {
    if (walletProvider) {
      try {
        await walletProvider.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: '0x38' }] // 56 in hex
        });
      } catch (error: any) {
        // Chain yoksa ekle
        if (error.code === 4902) {
          await walletProvider.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: '0x38',
              chainName: 'BNB Smart Chain',
              nativeCurrency: {
                name: 'BNB',
                symbol: 'BNB',
                decimals: 18
              },
              rpcUrls: ['https://bsc-dataseed.binance.org'],
              blockExplorerUrls: ['https://bscscan.com']
            }]
          });
        }
      }
    }
  };

  const handleCopyAddress = async () => {
    const addr = web3Address || walletAddress || address;
    if (addr) {
      await navigator.clipboard.writeText(addr);
      setCopied(true);
      toast({
        title: "Address Copied",
        description: "Wallet address copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  const currentAddress = web3Address || walletAddress || address;
  const connected = web3Connected || isConnected;

  if (connected && currentAddress) {
    return (
      <div className="flex items-center space-x-2">
        <div className="flex items-center space-x-2 bg-hermes-dark border border-hermes-border rounded-lg px-3 py-2 pt-[0px] pb-[0px]">
          <Wallet className="w-4 h-4 text-[var(--hermes-gold)]" />
          <span className="text-sm font-medium">{formatAddress(currentAddress)}</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopyAddress}
            className="p-1 h-auto hover:bg-hermes-border"
          >
            {copied ? (
              <Check className="w-3 h-3 text-green-400" />
            ) : (
              <Copy className="w-3 h-3 text-gray-400" />
            )}
          </Button>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={async () => {
            try {
              // Web3Modal disconnect
              await disconnect();
              // Store disconnect
              disconnectWallet();
              // No toast notification - silent disconnect as requested
            } catch (error) {
              console.error('Disconnect error:', error);
              // Only show error if something actually goes wrong
              toast({
                title: "Disconnect Error",
                description: "Wallet disconnection failed.",
                variant: "destructive"
              });
            }
          }}
          className="bg-hermes-dark border-hermes-border hover:bg-red-600/20 hover:border-red-500 transition-all duration-200"
          title="Disconnect Wallet"
        >
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
    );
  }

  // Custom connect handler with Web3Modal direct API
  const handleConnect = async () => {
    try {
      setLocalConnecting(true);
      console.log('Opening Web3Modal...');
      
      // Use Web3Modal's direct open method
      await open();
      
    } catch (error) {
      console.error('Connection error:', error);
      toast({
        title: t('errors.wallet_required'),
        description: "Cüzdan bağlantısında hata oluştu.",
        variant: "destructive"
      });
    } finally {
      setTimeout(() => setLocalConnecting(false), 1000);
    }
  };

  return (
    <>
      {/* Custom Connect Button for better mobile UX */}
      <Button 
        onClick={handleConnect}
        disabled={isConnecting || localConnecting}
        className="bg-[#6495ed] hover:bg-[#5884d8] text-white font-semibold px-6 py-2 rounded-lg transition-all duration-200 flex items-center space-x-2 ml-[7px] mr-[7px] pl-[18px] pr-[18px]"
      >
        {isMobile() ? <Smartphone className="w-4 h-4" /> : <Wallet className="w-4 h-4" />}
        <span>
          {(isConnecting || localConnecting) ? t('wallet.connecting') : 
           isMobile() ? t('wallet.mobile_connect') : t('wallet.connect')}
        </span>
      </Button>
      
      {/* Hidden Web3Modal button */}
      <w3m-button style={{ display: 'none' }} />
    </>
  );
}
