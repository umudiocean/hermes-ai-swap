import { createWeb3Modal, defaultConfig } from '@web3modal/ethers/react'

// Web3Modal Project ID from WalletConnect Cloud
const projectId = 'e1ce1bbc0f07c7cdf3c896b9cb0b7182'

// BSC Chain configuration with enterprise-grade RPC endpoints
const bscChain = {
  chainId: 56,
  name: 'BNB Smart Chain',
  currency: 'BNB',
  explorerUrl: 'https://bscscan.com',
  rpcUrl: 'https://bsc-dataseed.binance.org' // Primary endpoint, fallbacks handled by RpcManager
}

// Metadata - Universal configuration
const metadata = {
  name: 'Hermes AI Swap',
  description: 'Universal Multi-Wallet DeFi Exchange Platform',
  url: 'https://www.hermesaiswap.com',
  icons: ['https://www.hermesaiswap.com/hermes-logo.jpg']
}

// Create Web3Modal - Universal Multi-Wallet Support
createWeb3Modal({
  ethersConfig: defaultConfig({ 
    metadata,
    enableEIP6963: true, // Better desktop wallet detection
    enableInjected: true, // Enable injected wallets - crucial for MetaMask browser
    enableCoinbase: true, // Enable Coinbase Wallet SDK
    rpcUrl: 'https://bsc-dataseed.binance.org', // Fallback RPC
    defaultChainId: 56, // Force BSC as default
  }),
  chains: [bscChain],
  projectId,
  enableAnalytics: false,
  themeMode: 'dark',
  // Universal wallet access
  enableOnramp: false, // Disable buying crypto to reduce complexity
  // Featured wallets - all major providers supported
  featuredWalletIds: [
    'c57ca95b47569778a828d19178114f4db188b89b763c899ba0be274e97267d96', // MetaMask
    '4622a2b2d6af1c9844944291e5e7351a6aa24cd7b23099efac1b2fd875da31a0', // Trust Wallet  
    'fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa', // Coinbase Wallet
    '1ae92b26df02f0abca6304df07debccd18262fdf5fe82daa81593582dac9a369', // Rainbow
    'ecc4036f814562b41a5268adc86270ffa1365471402006302e70169465b7ac18', // Zerion
    '971e689d0a5be527bac79629b4ee9b925e82208e5168b733496a09c0faed0709', // OKX Wallet
    '19177a98252e07ddfc9af2083ba8e07ef627cb6103467ffebb3f8f4205fd7927', // Ledger Live
  ],
  // Universal configuration
  allowUnsupportedChain: false, // Force BSC only

  // Enhanced mobile UI
  themeVariables: {
    '--w3m-color-mix': '#1a1a1a',
    '--w3m-color-mix-strength': 40,
    '--w3m-accent': '#6495ed',
    '--w3m-font-size-master': '12px', // Larger text for mobile
    '--w3m-border-radius-master': '12px', // Larger touch targets
    '--w3m-z-index': 999999
  }
})

export { projectId }