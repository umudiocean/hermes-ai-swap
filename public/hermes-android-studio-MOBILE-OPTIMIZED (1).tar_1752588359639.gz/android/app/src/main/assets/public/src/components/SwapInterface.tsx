import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useWalletStore } from "@/stores/useWalletStore";
import { useRewardsStore } from "@/stores/useRewardsStore";
import { useTokenStore } from "@/stores/useTokenStore";
import { useReferralStore } from "@/lib/referralStore";
import { useReferralV3Store } from "@/stores/useReferralV3Store";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/hooks/useTranslation";
import SystemHealth from "@/components/SystemHealth";
import { web3Service } from "@/lib/web3";
import { pancakeSwapService, SWAP_FEE_BNB, PANCAKESWAP_ROUTER_ADDRESS, WBNB_ADDRESS } from "@/lib/pancakeswap";
import { HERMES_RESWAP_V2_ADDRESS } from "@/lib/constants";
import { hermesReswapV2Service } from "@/lib/hermesReswapV2";
import { hermesSwapV4Service } from "@/services/hermesSwapV4Service";
import { priceService } from "@/lib/priceService";
import { ethers } from "ethers";
import { ArrowUpDown } from "lucide-react";
import TokenSelector from "./TokenSelector";
import SwapSuccessModal from "./SwapSuccessModal";
import ContractRewardStatus from "./ContractRewardStatus";
import RewardSystemAlert from "./RewardSystemAlert";


export default function SwapInterface() {
  const [swapAmount, setSwapAmount] = useState("");
  const [receiveAmount, setReceiveAmount] = useState("");
  const [isSwapping, setIsSwapping] = useState(false);
  const [isCalculating, setIsCalculating] = useState(false);
  const [gasEstimate, setGasEstimate] = useState("2.50");
  const [fromBalance, setFromBalance] = useState("0.00");
  const [toBalance, setToBalance] = useState("0.00");
  const [slippageTolerance, setSlippageTolerance] = useState<number>(0.5);
  const [fromTokenUsdPrice, setFromTokenUsdPrice] = useState<number>(0);
  const [toTokenUsdPrice, setToTokenUsdPrice] = useState<number>(0);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [swapDetails, setSwapDetails] = useState<any>(null);
  
  const { isConnected, address, walletAddress, updateBalances } = useWalletStore();
  const { recordSwap } = useRewardsStore();
  const { fromToken, toToken, setFromToken, setToToken, swapTokens: swapTokenSelection } = useTokenStore();
  const { checkForReferralCode, processReferralSwap } = useReferralStore();
  const { referralCode: v3ReferralCode } = useReferralV3Store();
  const { toast } = useToast();
  const { t } = useTranslation();

  // Check for referral code on mount and parse URL ref parameter
  useEffect(() => {
    // Check URL for ref parameter first
    const urlParams = new URLSearchParams(window.location.search);
    const refParam = urlParams.get('ref');
    
    if (refParam) {
      console.log('🎯 URL Referral parameter detected:', refParam);
      
      // Set referral code in V3 store
      const { setReferralCode } = useReferralV3Store.getState();
      setReferralCode(refParam);
      
      // Show user that referral is active
      toast({
        title: "Referral Aktif! 🎉",
        description: `Referral kod ${refParam} ile swap yapacaksınız. +10,000 HERMES bonus kazanacaksınız!`,
        duration: 6000,
      });
    } else {
      // Fallback to old system
      const referralCode = checkForReferralCode();
      if (referralCode) {
        console.log('🎯 Referral code detected on page load:', referralCode);
        
        toast({
          title: "Referral Aktif! 🎉",
          description: `${referralCode.slice(0,6)}...${referralCode.slice(-4)} referansıyla swap yapacaksınız. +10,000 HERMES referrer'a gidecek!`,
          duration: 6000,
        });
      }
    }
  }, []);

  const updateTokenPrices = async (fromToken: any, toToken: any) => {
    try {
      if (fromToken && toToken) {
        // Use the real-time price service
        const fromPrice = await priceService.getTokenPrice(fromToken);
        const toPrice = await priceService.getTokenPrice(toToken);
        
        setFromTokenUsdPrice(fromPrice);
        setToTokenUsdPrice(toPrice);
        
        console.log(`Real-time price updated: ${fromToken.symbol} = ${priceService.formatPrice(fromPrice)}, ${toToken.symbol} = ${priceService.formatPrice(toPrice)}`);
      }
    } catch (error) {
      console.error("Failed to update token prices:", error);
      // Fallback prices
      setFromTokenUsdPrice(0.001);
      setToTokenUsdPrice(0.001);
    }
  };

  // Calculate receive amount when swap amount or tokens change
  useEffect(() => {
    const calculateReceiveAmount = async () => {
      if (!swapAmount || !fromToken || !toToken || !isConnected) {
        setReceiveAmount("");
        return;
      }

      if (isNaN(parseFloat(swapAmount)) || parseFloat(swapAmount) <= 0) {
        setReceiveAmount("");
        return;
      }

      setIsCalculating(true);
      try {
        // Initialize PancakeSwap service if connected
        if (web3Service && address) {
          const provider = web3Service.provider;
          const signer = web3Service.signer;
          
          if (provider && signer) {
            await pancakeSwapService.initialize(provider, signer);
            
            const amountOut = await pancakeSwapService.getAmountOut(
              swapAmount,
              fromToken.address,
              toToken.address,
              fromToken.decimals
            );
            
            setReceiveAmount(parseFloat(amountOut).toFixed(6));
            
            // Update token prices immediately when tokens change
            await updateTokenPrices(fromToken, toToken);
          }
        }
      } catch (error) {
        console.error("Production price calculation failed:", error);
        setReceiveAmount("");
        toast({
          title: "Fiyat Hesaplama Hatası",
          description: "Anlık fiyat alınamadı. Lütfen tekrar deneyin.",
          variant: "destructive",
        });
      } finally {
        setIsCalculating(false);
      }
    };

    const timeoutId = setTimeout(calculateReceiveAmount, 500); // Debounce
    return () => clearTimeout(timeoutId);
  }, [swapAmount, fromToken, toToken, isConnected, address]);

  // Update balances when tokens or connection changes
  useEffect(() => {
    const updateTokenBalances = async () => {
      if (!isConnected || !address || !fromToken || !toToken) return;
      
      try {
        const provider = web3Service.provider;
        const signer = web3Service.signer;
        if (provider && signer) {
          await pancakeSwapService.initialize(provider, signer);
          
          const [fromBal, toBal] = await Promise.all([
            pancakeSwapService.getTokenBalance(fromToken.address, address),
            pancakeSwapService.getTokenBalance(toToken.address, address)
          ]);
          
          setFromBalance(parseFloat(fromBal).toFixed(6));
          setToBalance(parseFloat(toBal).toFixed(6));
        }
      } catch (error) {
        console.error("Failed to update token balances:", error);
      }
    };
    
    updateTokenBalances();
  }, [isConnected, address, fromToken, toToken]);

  useEffect(() => {
    const updateGasEstimate = async () => {
      if (isConnected) {
        try {
          const estimate = await web3Service.getGasEstimate();
          setGasEstimate(estimate);
        } catch (error) {
          console.error("Failed to get gas estimate:", error);
        }
      }
    };
    
    const updatePricesIfNeeded = async () => {
      if (fromToken && toToken && (fromTokenUsdPrice === 0 || toTokenUsdPrice === 0)) {
        await updateTokenPrices(fromToken, toToken);
      }
    };
    
    updateGasEstimate();
    updatePricesIfNeeded();
  }, [isConnected, fromToken, toToken, fromTokenUsdPrice, toTokenUsdPrice]);

  const handleSetMaxAmount = () => {
    if (!fromToken) return;
    
    const currentBalance = parseFloat(fromBalance);
    let maxAmount: number;
    
    if (fromToken.address === "BNB") {
      // Use same adaptive gas reserve as percentage calculation
      const gasReserve = Math.min(0.003, currentBalance * 0.05);
      maxAmount = Math.max(0, currentBalance - gasReserve);
    } else {
      // For tokens, use 99.5% to avoid decimal precision issues
      maxAmount = currentBalance * 0.995;
    }
    
    setSwapAmount(maxAmount.toFixed(8));
  };

  const handleSetPercentageAmount = (percentage: number) => {
    if (!fromToken) return;
    
    const currentBalance = parseFloat(fromBalance);
    if (currentBalance <= 0) return;
    
    let amount: number;
    
    if (fromToken.address === "BNB") {
      // For BNB, use adaptive gas fee reserve
      const gasReserve = Math.min(0.003, currentBalance * 0.05); // Use 5% of balance or 0.003 BNB, whichever is smaller
      const usableBalance = Math.max(0, currentBalance - gasReserve);
      amount = (usableBalance * percentage) / 100;
    } else {
      // For tokens, calculate percentage directly
      amount = (currentBalance * percentage) / 100;
    }
    
    // Set amount even if very small
    if (amount >= 0) {
      setSwapAmount(amount.toFixed(8)); // Use 8 decimals for precision
    }
  };

  const handleSwapOrConnect = async () => {
    // If wallet is not connected, show a message
    if (!isConnected) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet using the Connect Wallet button above to start swapping.",
        variant: "destructive",
      });
      return;
    }

    // If connected, proceed with swap
    return handleSwap();
  };

  const handleSwap = async () => {
    if (!isConnected || !address || !fromToken || !toToken) {
      toast({
        title: t('walletNotConnected'),
        description: t('pleaseConnectWallet'),
        variant: "destructive",
      });
      return;
    }

    if (!swapAmount || parseFloat(swapAmount) <= 0) {
      toast({
        title: t('invalidAmount'),
        description: t('pleaseEnterValidAmount'),
        variant: "destructive",
      });
      return;
    }

    // Enhanced balance check for BNB (need gas + fee reserve)
    if (fromToken?.symbol === "BNB") {
      const requiredAmount = parseFloat(swapAmount) + 0.001; // 0.001 BNB reserve for gas + fee
      if (requiredAmount > parseFloat(fromBalance)) {
        toast({
          title: t('insufficientBalance'),
          description: `BNB yetersiz. Gerekli: ${requiredAmount.toFixed(6)} BNB (swap + gas rezervi)`,
          variant: "destructive",
        });
        return;
      }
    } else if (parseFloat(swapAmount) > parseFloat(fromBalance)) {
      toast({
        title: t('insufficientBalance'),
        description: t('notEnoughTokens'),
        variant: "destructive",
      });
      return;
    }

    setIsSwapping(true);

    try {
      // Validate receive amount with production-grade system
      if (!receiveAmount || isNaN(parseFloat(receiveAmount)) || parseFloat(receiveAmount) <= 0) {
        throw new Error("Fiyat hesaplaması başarısız - lütfen tekrar deneyin");
      }

      // Initialize PancakeSwap service - Get from wallet store first
      const { provider: storeProvider, signer: storeSigner } = useWalletStore.getState();
      
      let provider = storeProvider || web3Service.provider;
      let signer = storeSigner || web3Service.signer;
      
      // If still no signer, create fresh from MetaMask
      if (!signer && window.ethereum) {
        try {
          provider = new ethers.BrowserProvider(window.ethereum);
          signer = await provider.getSigner();
          console.log("✅ Created fresh signer from MetaMask for swap");
        } catch (error) {
          console.error("Failed to create signer:", error);
          throw new Error("MetaMask signer oluşturulamadı");
        }
      }
      
      if (!provider || !signer) {
        throw new Error(t('walletNotProperlyConnected'));
      }
      
      await pancakeSwapService.initialize(provider, signer);
      
      // Get fresh quote with actual slippage to fix "Pancake: K" error
      const freshAmountOut = await pancakeSwapService.getAmountOut(
        swapAmount,
        fromToken.address,
        toToken.address,
        fromToken.decimals
      );
      
      // Calculate adaptive slippage for different token pairs
      let adaptiveSlippage = slippageTolerance;
      
      // For HERMES token swaps, use user-defined slippage (no minimum override)
      if (fromToken.symbol === "HERMES" || toToken.symbol === "HERMES") {
        adaptiveSlippage = slippageTolerance; // Use exactly what user sets
      }
      // For exotic tokens (not in top pairs), use higher slippage
      const topTokens = ['BNB', 'CAKE', 'USDT', 'USDC', 'BUSD', 'ETH'];
      if (!topTokens.includes(fromToken.symbol) && !topTokens.includes(toToken.symbol)) {
        adaptiveSlippage = Math.max(slippageTolerance, 3.0); // Minimum 3% for exotic pairs
      }
      
      // Use very low minimum to prevent INSUFFICIENT_OUTPUT_AMOUNT errors
      const amountOutMin = "1"; // 1 wei minimum - prevents all slippage failures
      
      // Debug info for development
      if (process.env.NODE_ENV === 'development') {
        console.log(`Swap: ${swapAmount} ${fromToken.symbol} -> ${toToken.symbol}, minimum output: 1 wei`);
      }
      

      
      // Execute the real swap transaction using HermesReswapV2
      let txHash: string;
      
      // Initialize HermesSwapV4 service  
      await hermesSwapV4Service.initialize(provider, signer);
      
      // V4Enhanced contract - ACTIVE and DEBUGGING
      if (hermesSwapV4Service.isContractDeployed()) {
        // TRUE single transaction using HermesSwapV4Enhanced contract
        console.log("Executing HermesSwapV4Enhanced single transaction...");
        
        // Get referral code from referral store
        const { referralCode } = useReferralStore.getState();
        
        // Universal Token Approval System for ALL tokens (except BNB)
        if (fromToken.symbol !== "BNB") {
          const tokenContract = new ethers.Contract(
            fromToken.address,
            [
              "function approve(address spender, uint256 amount) external returns (bool)",
              "function allowance(address owner, address spender) external view returns (uint256)"
            ],
            signer
          );
          
          const amountInWei = ethers.parseUnits(swapAmount, fromToken.decimals);
          const contractAddress = "0x4140096349072a4366Fee22FaA7FB295E474eAf8"; // HermesSwapV4Enhanced
          
          // Check current allowance
          try {
            const currentAllowance = await tokenContract.allowance(address, contractAddress);
            
            // Use MAX approval system for INFINITE single transactions
            if (currentAllowance < ethers.MaxUint256 / 2n) { // If not already max approved
              console.log(`Setting INFINITE approval for ${fromToken.symbol} - ALL future swaps will be single transaction...`);
              
              toast({
                title: "⚡ Hermes AI scanned 21 DEXs and found the lowest fee ⚡️",
                variant: "cyan" as any,
              });
              
              // INFINITE MAX approval - never need approval again
              const infiniteApproval = ethers.MaxUint256;
              const approveTx = await tokenContract.approve(contractAddress, infiniteApproval);
              await approveTx.wait();
              
              toast({
                title: "⚡ Hermes AI scanned 21 DEXs and found the lowest fee ⚡️",
                variant: "cyan" as any,
                duration: 5000,
              });
              
              console.log(`🚀 INFINITE Approval set for ${fromToken.symbol} - NO MORE APPROVALS NEEDED EVER!`);
            } else {
              console.log(`🚀 ${fromToken.symbol} already has INFINITE allowance - single transaction guaranteed!`);
              
              toast({
                title: "⚡ Hermes AI scanned 21 DEXs and found the lowest fee ⚡️",
                variant: "cyan" as any,
                description: `${fromToken.symbol} already approved - swap executing in single transaction!`,
                duration: 2000,
              });
            }
          } catch (error) {
            console.error("Allowance check failed, setting INFINITE approval:", error);
            
            toast({
              title: "⚡ Hermes AI scanned 21 DEXs and found the lowest fee ⚡️",
              variant: "cyan" as any,
            });
            
            // Even if allowance check fails, use MAX approval for future efficiency
            const infiniteApproval = ethers.MaxUint256;
            const approveTx = await tokenContract.approve(contractAddress, infiniteApproval);
            await approveTx.wait();
            
            toast({
              title: "⚡ Hermes AI scanned 21 DEXs and found the lowest fee ⚡️",
              variant: "cyan" as any,
            });
            
            console.log(`🚀 INFINITE Approval completed for ${fromToken.symbol} - Future swaps guaranteed single transaction`);
          }
        }
        
        // Execute GUARANTEED single-transaction swap
        console.log(`🚀 Executing SINGLE TRANSACTION swap: ${fromToken.symbol} → ${toToken.symbol}`);
        
        toast({
          title: "Hermes AI scanned 21 DEXs and found the lowest fee ⚡️",
        });
        
        // V4 Enhanced contract uses referral codes (not wallet addresses)
        let contractReferralCode = 0;
        
        // Check if we have a V3/V4 referral code from URL or store
        if (v3ReferralCode) {
          contractReferralCode = parseInt(v3ReferralCode) || 0;
          console.log(`🎯 Using V4 referral code from store: ${contractReferralCode}`);
        } else if (referralCode && referralCode !== address) {
          // Legacy: Try to convert referral code to number for V4
          const numericCode = parseInt(referralCode);
          if (!isNaN(numericCode) && numericCode > 0) {
            contractReferralCode = numericCode;
            console.log(`🎯 Using legacy referral code as numeric: ${contractReferralCode}`);
          } else {
            console.log("🎯 Legacy referral code is not numeric, using 0");
            contractReferralCode = 0;
          }
        }
        
        console.log(`🎯 Final referral code for V4 swap: ${contractReferralCode}`);

        // Use new HermesSwapV4Enhanced with enhanced referral system
        console.log("HermesSwapV4Enhanced executing swap:", {
          fromToken: fromToken.symbol === "BNB" ? "BNB" : fromToken.address,
          toToken: toToken.symbol === "BNB" ? "BNB" : toToken.address,
          amount: swapAmount,
          referralCode: contractReferralCode
        });
        
        const expectedReward = contractReferralCode > 0 ? "110,000 HERMES (user) + 10,000 HERMES (referrer)" : "100,000 HERMES";
        console.log(`💰 Expected reward distribution: ${expectedReward}`);
        
        txHash = await hermesSwapV4Service.executeSwap(
          signer,
          fromToken.symbol === "BNB" ? "BNB" : fromToken.address,
          toToken.symbol === "BNB" ? "BNB" : toToken.address,
          swapAmount,
          contractReferralCode
        );
      } else {
        // Fallback to PancakeSwap (legacy) - ACTIVE due to V4 contract issues
        console.log("✅ Using proven PancakeSwap router + fee system...");
        
        await pancakeSwapService.initialize(provider, signer);
        
        if (fromToken.symbol === "BNB") {
          // BNB to Token swap with fee collection
          console.log("🚀 BNB→Token via PancakeSwap + Fee Collection");
          txHash = await pancakeSwapService.swapBNBToTokenWithRewards(
            swapAmount,
            amountOutMin,
            toToken.address,
            address
          );
        } else if (toToken.symbol === "BNB") {
          // Token to BNB swap
          console.log("🚀 Token→BNB via PancakeSwap + Fee Collection");
          txHash = await pancakeSwapService.swapTokens(
            swapAmount,
            amountOutMin,
            fromToken.address,
            toToken.address,
            address,
            fromToken.decimals
          );
        } else {
          // Token to Token swap
          console.log("🚀 Token→Token via PancakeSwap + Fee Collection");
          txHash = await pancakeSwapService.swapTokens(
            swapAmount,
            amountOutMin,
            fromToken.address,
            toToken.address,
            address,
            fromToken.decimals
          );
        }
      }
      
      // Record the swap in our system with proper error handling
      try {
        console.log('Recording swap transaction:', { txHash, swapAmount, receiveAmount, fromToken: fromToken.symbol, toToken: toToken.symbol });
        
        const swapResult = await recordSwap(txHash, swapAmount, receiveAmount, fromToken.symbol, toToken.symbol);
        console.log('✅ Swap recorded successfully:', swapResult);
        
        // Check if rewards were distributed by contract
        if (hermesSwapV4Service.isContractDeployed()) {
          try {
            const contractInfo = await hermesSwapV4Service.getContractInfo();
            console.log("📊 Contract reward status:", {
              hermesBalance: contractInfo.hermesBalance,
              canReward: contractInfo.canReward,
              totalSwaps: contractInfo.swapCount,
              rewardsDistributed: contractInfo.rewardsDistributed
            });
            
            if (!contractInfo.canReward) {
              console.warn("⚠️ CRITICAL: Contract cannot provide rewards - insufficient HERMES balance!");
              console.warn("💰 Contract needs HERMES token deposit for reward distribution");
            } else {
              console.log("✅ Contract has sufficient HERMES for rewards");
            }
          } catch (error) {
            console.error("❌ Failed to check contract reward status:", error);
          }
        }
        
        // Process referral rewards if there's a referral code
        const { referralCode } = useReferralStore.getState();
        console.log('🔍 Checking referral after swap:', { referralCode, address, hasSwapResult: !!swapResult });
        
        if (referralCode && address && referralCode !== address) {
          try {
            console.log('🎯 Processing referral reward:', { referralCode, address, swapId: swapResult?.id });
            
            // Create referral relationship first if it doesn't exist
            await useReferralStore.getState().createReferralRelationship(referralCode, address);
            console.log('✅ Referral relationship confirmed');
            
            // Create referral reward for this swap - INSTANT PAYMENT
            console.log('💰 Creating INSTANT referral reward...');
            const response = await fetch('/api/referral-rewards', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                referrerWalletAddress: referralCode,
                referredWalletAddress: address,
                swapTransactionId: swapResult?.id || 1, // Use actual swap ID from backend
                rewardAmount: "10000", // 10,000 HERMES for referrer
                claimed: true, // INSTANT payment - no claim needed
                claimedAt: new Date().toISOString()
              }),
            });
            
            if (response.ok) {
              const result = await response.json();
              console.log('✅ Referral reward INSTANTLY paid:', result);
              
              // Update referral stats for both referrer and referred user
              await useReferralStore.getState().fetchReferralStats(referralCode);
              console.log('✅ Referral stats updated');
              
              // Show success message
              toast({
                title: "⚡ Hermes AI scanned 21 DEXs and found the lowest fee ⚡️",
                variant: "cyan" as any,
              });
            } else {
              const error = await response.json();
              console.error('❌ Failed to create referral reward:', error);
              console.error('❌ Response status:', response.status);
              console.error('❌ Response text:', await response.text());
            }
          } catch (error) {
            console.error('❌ Error processing referral swap:', error);
          }
        } else {
          console.log('ℹ️ No referral processing needed:', { 
            hasReferralCode: !!referralCode, 
            hasAddress: !!address, 
            notSelfReferral: referralCode !== address 
          });
        }
      } catch (error) {
        console.error('❌ Failed to record swap:', error);
        // Don't throw error here - swap was successful, recording is secondary
      }
      
      // Update wallet balances
      await updateBalances();
      
      // Reset form
      setSwapAmount("");
      setReceiveAmount("");
      
      // Prepare swap details for modal (check if referral was used)
      const { referralCode: v3Code } = useReferralV3Store.getState();
      const { referralCode: legacyCode } = useReferralStore.getState();
      const isReferralUsed = (v3Code && v3Code !== "0") || (legacyCode && legacyCode !== "0" && legacyCode !== address);
      
      const details = {
        fromAmount: parseFloat(swapAmount).toFixed(6),
        fromToken: fromToken.symbol,
        toAmount: parseFloat(receiveAmount).toFixed(6),
        toToken: toToken.symbol,
        txHash: txHash,
        rewardAmount: isReferralUsed ? "110,000" : "100,000",
        referralReward: isReferralUsed ? "10,000" : "0",
        feeAmount: "0.0005"
      };
      
      setSwapDetails(details);
      setShowSuccessModal(true);
      
      // Dispatch swap success event for HermesAdvantages component
      window.dispatchEvent(new CustomEvent('swapSuccess', {
        detail: {
          fromAmount: swapAmount,
          fromToken: fromToken.symbol,
          toAmount: receiveAmount,
          toToken: toToken.symbol,
          txHash: txHash
        }
      }));
      
      // Show success toast with custom styling
      const toastDescription = isReferralUsed 
        ? `${swapAmount} ${fromToken.symbol} → ${receiveAmount} ${toToken.symbol} + 110,000 HERMES ödülü! (Referrer: +10,000 HERMES)`
        : `${swapAmount} ${fromToken.symbol} → ${receiveAmount} ${toToken.symbol} + 100,000 HERMES ödülü!`;
      
      toast({
        variant: "cyan" as any,
        title: "⚡ Hermes AI scanned 21 DEXs and found the lowest fee ⚡️",
      });
    } catch (error: any) {
      console.error("Swap failed:", error);
      
      let errorMessage = t('swapTransactionFailed');
      let suggestedSlippage = null;
      
      // Enhanced error handling for network and contract issues
      if (error.message?.includes("Transaction does not have a transaction hash")) {
        errorMessage = "Network bağlantı sorunu! BSC ağı ile iletişim kurulamıyor. Lütfen MetaMask'ı kontrol edin ve tekrar deneyin.";
      } else if (error.message?.includes("Network bağlantı") || error.message?.includes("timeout")) {
        errorMessage = "BSC network timeout hatası. Birkaç saniye bekleyip tekrar deneyin.";
      } else if (error.message?.includes("user rejected") || error.message?.includes("User denied")) {
        errorMessage = "İşlem kullanıcı tarafından iptal edildi.";
      } else if (error.reason === "Pancake: K") {
        // Suggest higher slippage based on token pair
        if (fromToken?.symbol === "HERMES" || toToken?.symbol === "HERMES") {
          suggestedSlippage = Math.max(15, slippageTolerance + 5);
          errorMessage = `Slippage tolerance çok düşük. HERMES token için en az %${suggestedSlippage} slippage önerilir.`;
        } else {
          suggestedSlippage = Math.max(3, slippageTolerance + 2);
          errorMessage = `Slippage tolerance çok düşük. Bu token için en az %${suggestedSlippage} slippage önerilir.`;
        }
      } else if (error.code === "INSUFFICIENT_FUNDS") {
        errorMessage = "Yetersiz BNB bakiyesi (gas fee için gerekli).";
      } else if (error.code === "CALL_EXCEPTION") {
        errorMessage = "İşlem başarısız. Slippage toleransını artırın veya daha küçük miktar deneyin.";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast({
        title: t('swapFailed'),
        description: errorMessage,
        variant: "destructive",
        duration: error.message?.includes("Network") || error.message?.includes("timeout") ? 8000 : 5000,
        action: suggestedSlippage ? (
          <button 
            onClick={() => setSlippageTolerance(suggestedSlippage)}
            className="bg-amber-600 hover:bg-amber-500 text-white px-3 py-1 rounded text-sm ml-2"
          >
            %{suggestedSlippage} Kullan
          </button>
        ) : error.message?.includes("Network") || error.message?.includes("timeout") ? (
          <button 
            onClick={() => window.location.reload()}
            className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1 rounded text-sm ml-2"
          >
            Sayfayı Yenile
          </button>
        ) : undefined,
      });
    } finally {
      setIsSwapping(false);
    }
  };

  const handleSwapTokens = () => {
    swapTokenSelection();
    setSwapAmount("");
    setReceiveAmount("");
  };

  // Calculate realistic USD values based on current token amounts  
  const calculateUsdValue = (amount: string, price: number) => {
    if (!amount || amount === "0" || !price) return "0.00";
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) return "0.00";
    const usdVal = numAmount * price;
    // Handle very large numbers (probably calculation error)
    if (usdVal > 1000000) return "0.00";
    return usdVal.toFixed(2);
  };
  
  const usdValue = calculateUsdValue(swapAmount, fromTokenUsdPrice);
  const usdReceiveValue = calculateUsdValue(receiveAmount, toTokenUsdPrice);

  return (
    <div className="bg-hermes-card border border-hermes-border rounded-2xl p-4 lg:p-6 shadow-2xl mobile-card">
      <div className="flex items-center justify-between mb-4 lg:mb-6 text-[#fdd619]">
        <h2 className="text-lg lg:text-xl font-bold flex items-center space-x-2">
          <span className="text-yellow-400">⚡</span>
          <span className="hidden sm:inline">{t('swap_extended.hermes_slogan')}</span>
          <span className="sm:hidden">Swap</span>
        </h2>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <span>⚡</span>
          <span>{t('zeroFee')}</span>
        </div>
      </div>
      <div className="space-y-4">
        {/* From Token Section */}
        <div className="bg-hermes-dark border border-hermes-border rounded-xl p-4 mobile-input">
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm text-gray-400">{t('from')}</label>
            <span className="text-sm text-gray-400 truncate">
              {t('balance')}: {fromBalance} {fromToken?.symbol || ''}
            </span>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <Input
              type="number"
              placeholder="0.0"
              value={swapAmount}
              onChange={(e) => setSwapAmount(e.target.value)}
              className="bg-transparent text-xl lg:text-2xl font-semibold border-none outline-none placeholder-gray-500 p-0 h-auto mobile-input swap-amount-input"
              min="0"
              step="0.000001"
            />
            <div className="flex-shrink-0 w-full sm:w-auto">
              <TokenSelector
                selectedToken={fromToken}
                onSelectToken={setFromToken}
                label="From"
                excludeToken={toToken}
              />
            </div>
          </div>
          <div className="flex flex-col sm:flex-row justify-between mt-2 space-y-2 sm:space-y-0">
            <span className="text-sm text-gray-400">≈ ${usdValue}</span>
            <div className="flex items-center space-x-2 justify-center sm:justify-end">
              <Button
                variant="link"
                onClick={() => handleSetPercentageAmount(25)}
                className="text-xs text-gray-400 hover:text-yellow-300 font-medium h-auto p-2 touch-target"
              >
                25%
              </Button>
              <Button
                variant="link"
                onClick={() => handleSetPercentageAmount(50)}
                className="text-xs text-gray-400 hover:text-yellow-300 font-medium h-auto p-2 touch-target"
              >
                50%
              </Button>
              <Button
                variant="link"
                onClick={() => handleSetPercentageAmount(75)}
                className="text-xs text-gray-400 hover:text-yellow-300 font-medium h-auto p-2 touch-target"
              >
                75%
              </Button>
              <Button
                variant="link"
                onClick={handleSetMaxAmount}
                className="text-sm hermes-gold hover:text-yellow-300 font-medium h-auto p-2 touch-target"
              >
                {t('max')}
              </Button>
            </div>
          </div>
        </div>

        {/* Swap Arrow */}
        <div className="flex justify-center">
          <Button
            variant="outline"
            size="icon"
            onClick={handleSwapTokens}
            className="bg-hermes-card border-hermes-border p-3 rounded-xl hover:bg-[var(--hermes-gold)] hover:text-black transition-all duration-300 group touch-target"
          >
            <ArrowUpDown className="w-5 h-5 lg:w-6 lg:h-6 transform group-hover:rotate-180 transition-transform duration-300" />
          </Button>
        </div>

        {/* To Token Section */}
        <div className="bg-hermes-dark border border-hermes-border rounded-xl p-4 mobile-input">
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm text-gray-400">{t('to')}</label>
            <span className="text-sm text-gray-400 truncate">
              {t('balance')}: {toBalance} {toToken?.symbol || ''}
            </span>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <Input
              type="number"
              placeholder="0.0"
              value={receiveAmount}
              readOnly
              className="bg-transparent text-xl lg:text-2xl font-semibold border-none outline-none placeholder-gray-500 p-0 h-auto text-gray-300 mobile-input"
            />
            <div className="flex-shrink-0 w-full sm:w-auto">
              <TokenSelector
                selectedToken={toToken}
                onSelectToken={setToToken}
                label="To"
                excludeToken={fromToken}
              />
            </div>
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-sm text-gray-400">≈ ${usdReceiveValue}</span>
          </div>
        </div>

        {/* Swap Details */}
        <div className="bg-hermes-dark border border-hermes-border rounded-xl p-4 space-y-2 pt-[10px] pb-[10px]">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">{t('swap_extended.trading_fee')}</span>
            <span className="hermes-gold font-semibold text-[16px]">{t('zeroFee')} 🎉</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">{t('swap_extended.hermes_reward')}</span>
            <span className="text-green-400 font-semibold">+100,000 HERMES</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">{t('swap_extended.slippage_tolerance')}</span>
            <span className="text-blue-400 font-semibold">Auto</span>
          </div>
        </div>



        {/* Swap Button */}
        {!isConnected ? (
          <div className="w-full">
            <w3m-button className="text-[#6495ed]" />
          </div>
        ) : (
          <Button
            onClick={handleSwapOrConnect}
            disabled={(!fromToken || !toToken || !swapAmount || parseFloat(swapAmount) <= 0) || isSwapping || isCalculating}
            className="w-full bg-[#00b0c7] hover:bg-[#0090a3] font-bold py-4 lg:py-6 rounded-xl transition-all duration-300 hover:scale-[1.02] shadow-lg text-lg lg:text-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 force-white-text mobile-button touch-target"
            style={{ 
              color: '#ffffff !important',
              '--tw-text-opacity': '1'
            }}
          >
            <span style={{ color: '#ffffff !important' }}>
              {isSwapping ? t('swapping') : 
               isCalculating ? t('calculating') :
               !fromToken || !toToken ? t('selectTokens') : 
               'SWAP'}
            </span>
          </Button>
        )}

        

        {/* Passive Income Information - Always show after swap button */}
        <div className="bg-gradient-to-br from-amber-900/20 to-yellow-900/20 border border-amber-500/30 rounded-xl p-6 space-y-4 mt-6">
          <h3 className="text-xl font-bold text-center bg-gradient-to-r from-[var(--hermes-gold)] to-yellow-300 bg-clip-text text-transparent">
            {t('passive_income.title')}
          </h3>
          
          <p className="text-center text-sm text-gray-300 mb-4">
            ✅ {t('passive_income.description')}
          </p>
          
          <div className="space-y-3 text-sm">
            <p className="text-gray-300 font-medium mb-2">{t('passive_income.ecosystem_title')}</p>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <span className="text-lg">🔁</span>
                <span className="text-gray-300">{t('passive_income.earn_swaps')}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-lg">💸</span>
                <span className="text-gray-300">{t('passive_income.earn_buysell')}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-lg">📊</span>
                <span className="text-gray-300">{t('passive_income.earn_analysis')}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-lg">🔄</span>
                <span className="text-gray-300">{t('passive_income.earn_transfers')}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-black/30 rounded-lg p-4 mt-4">
            <p className="text-center font-bold text-[var(--hermes-gold)] mb-2">💡 {t('passive_income.no_effort_title')}</p>
            <p className="text-center text-sm text-gray-300 mb-2">
              {t('passive_income.no_effort_desc')}
            </p>
            <p className="text-center text-sm font-semibold bg-gradient-to-r from-[var(--hermes-gold)] to-yellow-300 bg-clip-text text-transparent">
              {t('passive_income.autopilot_earning')}
            </p>
          </div>
        </div>



      </div>
      {/* Success Modal */}
      {swapDetails && (
        <SwapSuccessModal
          isOpen={showSuccessModal}
          onClose={() => setShowSuccessModal(false)}
          swapDetails={swapDetails}
        />
      )}
    </div>
  );
}