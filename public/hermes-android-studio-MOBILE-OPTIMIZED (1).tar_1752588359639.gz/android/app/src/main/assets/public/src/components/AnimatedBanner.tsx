import DEXAnalysisDashboard from './DEXAnalysisDashboard';

export default function AnimatedBanner() {
  return <DEXAnalysisDashboard />;
}
