import { useState, useEffect } from "react";
import { useWalletStore } from "@/stores/useWalletStore";
import { Button } from "@/components/ui/button";
import { Wallet, RefreshCw, Copy, Check } from "lucide-react";
import { HERMES_CONTRACT_ADDRESS } from "@/lib/constants";
import { priceService } from "@/lib/priceService";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/hooks/useTranslation";

export default function HermesWalletBalance() {
  const { address, hermesBalance, updateBalances } = useWalletStore();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [hermesUsdValue, setHermesUsdValue] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [copied, setCopied] = useState(false);

  // Get HERMES balance from wallet store
  const hermesAmount = parseFloat(hermesBalance || "0");
  
  // Debug logging removed for production

  // Update USD value when balance changes
  useEffect(() => {
    const updateHermesPrice = async () => {
      try {
        const price = await priceService.getTokenPrice({
          address: HERMES_CONTRACT_ADDRESS,
          symbol: "HERMES",
          decimals: 18
        } as any);
        
        if (price && price > 0) {
          setHermesUsdValue(hermesAmount * price);
        } else {
          // Use fallback price from real-time pricing
          setHermesUsdValue(hermesAmount * 0.00000019); // Current HERMES price
        }
      } catch (error) {
        console.error("Failed to get HERMES price:", error);
        // Fallback to current market price
        setHermesUsdValue(hermesAmount * 0.00000019);
      }
    };

    if (hermesAmount > 0) {
      updateHermesPrice();
    } else {
      setHermesUsdValue(0);
    }
  }, [hermesAmount]);

  // Force update when wallet address changes
  useEffect(() => {
    if (address) {
      updateBalances();
    }
  }, [address]);

  // Auto-refresh every 5 minutes and listen for swap events
  useEffect(() => {
    const interval = setInterval(async () => {
      if (address) {
        await handleRefresh();
      }
    }, 5 * 60 * 1000); // 5 minutes

    // Listen for swap success events to update balance
    const handleSwapSuccess = async () => {
      if (address) {
        setTimeout(async () => {
          await handleRefresh();
        }, 3000); // Wait 3 seconds after swap for blockchain confirmation
      }
    };

    window.addEventListener('swapSuccess', handleSwapSuccess);

    return () => {
      clearInterval(interval);
      window.removeEventListener('swapSuccess', handleSwapSuccess);
    };
  }, [address]);

  const handleRefresh = async () => {
    if (!address) return;
    
    setIsRefreshing(true);
    try {
      await updateBalances();
      setLastUpdate(new Date());
      // Balance updated silently - no toast notification
    } catch (error) {
      console.error("Failed to refresh balance:", error);
      // Balance update error - no toast notification
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleCopyAddress = async () => {
    if (!address) return;
    
    try {
      await navigator.clipboard.writeText(address);
      setCopied(true);
      toast({
        title: t("wallet.address_copied", "Address Copied"),
        description: t("wallet.address_copied_desc", "Wallet address copied to clipboard"),
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: t("wallet.copy_error", "Copy Error"),
        description: t("wallet.copy_error_desc", "Address could not be copied"),
        variant: "destructive",
      });
    }
  };

  const formatBalance = (balance: number) => {
    if (balance === 0) return "0";
    if (balance < 1) {
      return balance.toFixed(8).replace(/\.?0+$/, "");
    }
    return balance.toLocaleString();
  };

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  const handleAddToWallet = async () => {
    try {
      if (!window.ethereum) {
        toast({
          title: "MetaMask Bulunamadı",
          description: "MetaMask yüklü değil",
          variant: "destructive",
        });
        return;
      }

      await window.ethereum.request({
        method: 'wallet_watchAsset',
        params: {
          type: 'ERC20',
          options: {
            address: HERMES_CONTRACT_ADDRESS,
            symbol: 'HERMES',
            decimals: 18,
            image: 'https://i.imgur.com/placeholder.png',
          },
        },
      });

      toast({
        title: t("wallet.token_added", "Token Added"),
        description: t("wallet.token_added_desc", "HERMES token added to your wallet"),
      });
    } catch (error) {
      console.error("Failed to add token:", error);
      toast({
        title: t("wallet.token_add_error", "Token Add Error"),
        description: t("wallet.token_add_error_desc", "Error occurred while adding token to wallet"),
        variant: "destructive",
      });
    }
  };

  if (!address) {
    return (
      <div className="bg-hermes-card border border-hermes-border rounded-2xl p-6 shadow-2xl">
        <div className="text-center text-gray-400">
          <Wallet className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>{t("wallet.not_connected", "Wallet not connected")}</p>
          <p className="text-sm">{t("wallet.connect_to_view", "Connect your wallet to view HERMES balance")}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-hermes-card border border-hermes-border rounded-2xl p-6 shadow-2xl pt-[0px] pb-[0px] pl-[12px] pr-[12px]">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold flex items-center gap-2">
          <Wallet className="w-5 h-5 text-hermes-gold" />
          {t("wallet.hermes_balance", "HERMES Balance")}
        </h3>
        <Button
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="p-2 bg-hermes-dark hover:bg-gray-700 rounded-lg transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
        </Button>
      </div>
      {/* Balance Display */}
      <div className="bg-hermes-dark rounded-xl p-4 mb-4">
        <div className="text-center">
          {/* Token Amount */}
          <div className="text-2xl font-bold text-hermes-gold mb-1">
            {formatBalance(hermesAmount)}
          </div>
          <div className="text-sm text-gray-400 mb-3">HERMES</div>
          
          {/* USD Value */}
          <div className="text-lg font-semibold text-white">
            ${hermesUsdValue >= 1 ? hermesUsdValue.toFixed(2) : 
              hermesUsdValue >= 0.01 ? hermesUsdValue.toFixed(4) : 
              hermesUsdValue >= 0.0001 ? hermesUsdValue.toFixed(6) : 
              hermesUsdValue.toExponential(2)}
          </div>
          <div className="text-xs text-gray-500">{t("wallet.usd_value", "USD Value")}</div>
        </div>
      </div>
      {/* Wallet Address */}
      <div className="bg-hermes-dark rounded-lg p-3 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="text-xs text-gray-400 mb-1">{t("wallet.wallet_address", "Wallet Address")}</div>
            <div className="text-sm font-mono text-gray-300">
              {formatAddress(address)}
            </div>
          </div>
          <Button
            onClick={handleCopyAddress}
            className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors ml-2"
          >
            {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
      </div>
      {/* Add to Wallet Button */}
      <Button
        onClick={handleAddToWallet}
        className="w-full bg-[#00b0c7] hover:bg-[#0090a3] text-white font-semibold py-2 px-4 rounded-lg transition-colors mb-3"
      >
{t("wallet.add_token", "Add Hermes Coin to Wallet")}
      </Button>
      {/* Contract Address */}
      <div className="bg-hermes-dark rounded-lg p-3 mb-4">
        <div className="text-xs text-gray-400 mb-1">{t("wallet.smart_contract", "Smart Contract")}</div>
        <div className="text-xs font-mono text-gray-300 break-all">
          {HERMES_CONTRACT_ADDRESS}
        </div>
      </div>
      {/* Last Update */}
      {lastUpdate && (
        <div className="text-xs text-gray-500 text-center">
{t("wallet.last_update", "Last update")}: {lastUpdate.toLocaleTimeString()}
        </div>
      )}
      {/* Auto-refresh info */}
      <div className="text-xs text-gray-600 text-center mt-2">
{t("wallet.auto_update", "Auto-refresh: Every 5 minutes")}
      </div>
    </div>
  );
}