import { useTranslation } from '../hooks/useTranslation';
import { useWalletStore } from '../stores/useWalletStore';
import { Copy, ExternalLink, Users, TrendingUp, Gift, Zap, QrCode } from 'lucide-react';
import { useToast } from '../hooks/use-toast';
import { useReferralStore } from '../lib/referralStore';
import { Button } from '../components/ui/button';
import WalletConnect from '../components/WalletConnect';
import ReferralV3System from '../components/ReferralV3System';
import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { 
  ReferralIcon, 
  SwapIcon, 
  ClaimIcon, 
  EarningsIcon, 
  WalletIcon,
  SecurityIcon,
  OptimizationIcon,
  ScanningIcon 
} from '../components/icons/ModernIcons';

export default function ReferralPage() {
  const { t } = useTranslation();
  const { address } = useWalletStore();
  const { toast } = useToast();
  const [isClaiming, setIsClaiming] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  
  const {
    referralStats,
    unclaimedRewards,
    referrals,
    isLoading,
    generateReferralLink,
    fetchReferralStats,
    fetchUnclaimedRewards,
    fetchReferrals,
    claimRewards
  } = useReferralStore();

  const referralLink = address ? generateReferralLink(address) : '';

  useEffect(() => {
    if (address) {
      fetchReferralStats(address);
      fetchUnclaimedRewards(address);
      fetchReferrals(address);
    }
  }, [address]);

  const generateQRCode = async () => {
    if (referralLink) {
      try {
        const qrUrl = await QRCode.toDataURL(referralLink, {
          width: 200,
          margin: 2,
          color: {
            dark: '#000000',
            light: '#FFFFFF'
          }
        });
        setQrCodeUrl(qrUrl);
      } catch (error) {
        console.error('QR Code generation failed:', error);
      }
    }
  };

  useEffect(() => {
    if (referralLink) {
      generateQRCode();
    }
  }, [referralLink]);

  const copyReferralLink = () => {
    if (referralLink) {
      navigator.clipboard.writeText(referralLink);
      toast({
        title: t('referral.copied'),
        description: t('referral.referral_link_copied'),
      });
    }
  };

  // Claim function removed - instant payments now active

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-[var(--hermes-gold)] to-yellow-300 bg-clip-text text-transparent mb-4">
            {t('referral.system_v3_title')}
          </h1>
          <div className="text-xl text-gray-300 space-y-2 max-w-4xl mx-auto">
            <p>🔗 {t('referral.smart_referral_codes_desc')}</p>
            <p>👥 {t('referral.enhanced_rewards_desc')}</p>
            <p>💸 {t('referral.instant_payments_desc')}</p>
            <p>📊 {t('referral.onchain_tracking_desc')}</p>
            <p>🚀 {t('referral.professional_influencer_desc')}</p>
          </div>
        </div>
        
        {/* V3 Referral System */}
        <div className="mb-12">
          <ReferralV3System />
        </div>

        {address ? (
          <>
            {/* Legacy Stats Overview (for comparison) */}
            <div className="bg-gray-800/50 border border-gray-600 rounded-2xl p-6 mb-8">
              <h3 className="text-xl font-bold hermes-gold mb-4">{t('referral.system_v3_title')} - {t('referral.real_hermes_rewards')}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                <div className="bg-hermes-card border border-hermes-border rounded-2xl p-6 text-center">
                  <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                  <h3 className="text-lg font-semibold mb-1">{t('referral.total_referrals')}</h3>
                  <p className="text-3xl font-bold text-hermes-gold">{referralStats?.totalReferrals || 0}</p>
                  <p className="text-sm text-gray-400 mt-1">{t('referral.total_referrals')}</p>
                </div>
              
                <div className="bg-hermes-card border border-hermes-border rounded-2xl p-6 text-center">
                  <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <h3 className="text-lg font-semibold mb-1">{t('referral.swaps_by_referrals')}</h3>
                  <p className="text-3xl font-bold text-hermes-gold">{referralStats?.totalReferralSwaps || 0}</p>
                  <p className="text-sm text-gray-400 mt-1">{t('referral.swaps_by_referrals')}</p>
                </div>
              
                <div className="bg-hermes-card border border-hermes-border rounded-2xl p-6 text-center">
                  <Gift className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <h3 className="text-lg font-semibold mb-1">{t('referral.earned_bonuses')}</h3>
                  <p className="text-3xl font-bold text-hermes-gold">{((referralStats?.totalReferralSwaps || 0) * 10000).toLocaleString()}</p>
                  <p className="text-sm text-gray-400 mt-1">HERMES ({t('wallet.balance')})</p>
                </div>
              </div>
            </div>

            {/* Instant Rewards Card */}
            <div className="bg-hermes-card border border-hermes-border rounded-2xl p-8 max-w-lg mx-auto">
                <div className="text-center mb-6">
                  <div className="mx-auto mb-4 flex items-center justify-center">
                    <Zap className="w-16 h-16 text-yellow-400" />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{t('referral.instant_payments_desc')}</h3>
                  <p className="text-gray-400">{t('referral.automatic_tracking')}</p>
                </div>

                <div className="space-y-4">
                  <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 text-center">
                    <div className="text-3xl font-bold text-yellow-400 mb-2">
                      {((referralStats?.totalReferralSwaps || 0) * 10000).toLocaleString()}
                    </div>
                    <div className="text-gray-400">{t('referral.earned_bonuses')}</div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg p-4 text-center">
                    <div className="text-white font-bold flex items-center justify-center">
                      <Zap className="w-4 h-4 mr-2" />
                      {t('referral.automatic_tracking')}
                    </div>
                    <div className="text-green-100 text-sm mt-1">
                      {t('referral.instant_payments_desc')}
                    </div>
                  </div>
                  
                  {(referralStats?.totalReferralSwaps || 0) === 0 && (
                    <p className="text-center text-gray-500 text-sm">
                      {t('referral.share_to_earn')}
                    </p>
                  )}
                </div>
              </div>

            

            {/* Influencer Section */}
            <div className="mt-8 bg-gradient-to-r from-purple-900/50 to-pink-900/50 border border-purple-500/30 rounded-2xl p-8">
              <div className="text-center">
                <h3 className="text-3xl font-bold mb-4 flex items-center justify-center gap-3">
                  <ScanningIcon size={48} />
{t('referral.unlimited_earning')}
                </h3>
                <div className="grid md:grid-cols-3 gap-6 text-center">
                  <div>
                    <div className="mb-4 flex justify-center">
                      <SecurityIcon size={48} />
                    </div>
                    <div className="font-bold">{t('referral.no_referral_limit')}</div>
                    <div className="text-gray-400 text-sm">{t('referral.invite_unlimited')}</div>
                  </div>
                  <div>
                    <div className="mb-4 flex justify-center">
                      <EarningsIcon size={48} />
                    </div>
                    <div className="font-bold">{t('referral.hermes_per_swap')}</div>
                    <div className="text-gray-400 text-sm">{t('referral.earn_per_swap')}</div>
                  </div>
                  <div>
                    <div className="mb-4 flex justify-center">
                      <OptimizationIcon size={48} />
                    </div>
                    <div className="font-bold">{t('referral.automatic_tracking')}</div>
                    <div className="text-gray-400 text-sm">{t('referral.realtime_stats')}</div>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-12">
            <div className="bg-hermes-card border border-hermes-border rounded-2xl p-12 max-w-md mx-auto">
              <div className="mx-auto mb-6 flex items-center justify-center">
                <WalletIcon size={80} />
              </div>
              <h3 className="text-2xl font-bold mb-4">{t('referral.get_started')}</h3>
              <p className="text-gray-400 mb-6">{t('referral.get_started_desc')}</p>
              <WalletConnect />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}