import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import "./lib/i18n"; // Initialize i18n system
// Web3Modal types declared globally
import "./lib/web3modal"; // Initialize Web3Modal
import "./lib/pancakeswapMobile"; // PancakeSwap-style mobile redirect

// PancakeSwap-style mobile redirect is auto-executed in pancakeswapMobile.ts

// MetaMask mobile browser auto-connection optimization
if (typeof window !== 'undefined') {
  const isMetaMaskBrowser = window.navigator.userAgent.includes('MetaMask') || 
                           window.ethereum?.isMetaMask;
  
  if (isMetaMaskBrowser) {
    // Auto-detect MetaMask in mobile browser and prepare for connection
    console.log('MetaMask mobile browser detected - optimizing experience');
    
    // Force proper viewport for MetaMask browser
    const viewport = document.querySelector('meta[name="viewport"]');
    if (viewport) {
      viewport.setAttribute('content', 
        'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover'
      );
    }
    
    // Prevent MetaMask browser scroll issues
    document.documentElement.style.height = '100%';
    document.body.style.height = '100%';
    document.body.style.overflow = 'auto';
  }
}

createRoot(document.getElementById("root")!).render(<App />);
