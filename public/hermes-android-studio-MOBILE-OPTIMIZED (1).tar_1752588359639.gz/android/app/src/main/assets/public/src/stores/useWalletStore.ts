import { create } from "zustand";
import { web3Service } from "@/lib/web3";
import { HERMES_CONTRACT_ADDRESS } from "@/lib/constants";

interface WalletState {
  isConnected: boolean;
  address: string | null;
  walletAddress: string | null;
  bnbBalance: string;
  hermesBalance: string;
  isConnecting: boolean;
  error: string | null;
  provider: any;
  signer: any;
  walletName: string | null;
  
  // Actions
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  updateBalances: () => Promise<void>;
  clearError: () => void;
  setWalletData: (provider: any, signer: any, address: string, walletName: string) => void;
}

export const useWalletStore = create<WalletState>((set, get) => ({
  isConnected: false,
  address: null,
  walletAddress: null,
  bnbBalance: "0.00",
  hermesBalance: "0.00",
  isConnecting: false,
  error: null,
  provider: null,
  signer: null,
  walletName: null,

  connectWallet: async () => {
    set({ isConnecting: true, error: null });
    
    try {
      const address = await web3Service.connectWallet();
      set({ 
        isConnected: true, 
        address,
        isConnecting: false 
      });
      
      // Update balances after connection
      await get().updateBalances();
    } catch (error: any) {
      set({ 
        isConnecting: false, 
        error: error.message || "Failed to connect wallet" 
      });
    }
  },

  disconnectWallet: () => {
    web3Service.disconnect();
    set({
      isConnected: false,
      address: null,
      walletAddress: null,
      bnbBalance: "0.00",
      hermesBalance: "0.00",
      error: null,
      provider: null,
      signer: null,
      walletName: null
    });
  },

  setWalletData: (provider: any, signer: any, address: string, walletName: string) => {
    // Update web3Service with new provider and signer
    if (web3Service.setProvider) {
      web3Service.setProvider(provider, signer);
    }
    
    set({ 
      isConnected: true,
      address,
      walletAddress: address,
      provider,
      signer,
      walletName,
      isConnecting: false,
      error: null
    });
    
    // Update balances after connection
    get().updateBalances();
  },

  updateBalances: async () => {
    const { address } = get();
    if (!address) return;

    try {
      const [bnbBalance, hermesBalance] = await Promise.all([
        web3Service.getBNBBalance(address),
        web3Service.getHermesBalance(address, HERMES_CONTRACT_ADDRESS),
      ]);

      set({ 
        bnbBalance: parseFloat(bnbBalance).toFixed(4),
        hermesBalance: parseFloat(hermesBalance).toFixed(2),
      });
    } catch (error: any) {
      console.error("Failed to update balances:", error);
      set({ error: "Failed to update balances" });
    }
  },

  clearError: () => set({ error: null }),
}));
