import React, { useState, useEffect } from 'react';
import { X, Smartphone, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { isMobile, generateWalletDeepLink } from '@/lib/mobileWallet';

export default function MobileBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Universal mobile access - no forced redirects
    if (isMobile()) {
      console.log('Mobile device detected - Web3Modal will handle wallet connections');
    }
    
    // No banner shown - Web3Modal provides universal wallet access
    setIsVisible(false);
  }, [dismissed]);

  const handleDismiss = () => {
    setIsVisible(false);
    setDismissed(true);
    // Remember dismissal for this session
    sessionStorage.setItem('mobileBannerDismissed', 'true');
  };

  const handleOpenInWallet = () => {
    const currentUrl = window.location.href;
    const metamaskLink = generateWalletDeepLink('metamask', currentUrl);
    
    // Direct redirect without asking - PancakeSwap style
    window.location.href = metamaskLink;
  };

  // Don't render if not mobile or dismissed
  if (!isMobile() || !isVisible) {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 animate-in slide-in-from-bottom duration-300">
      <div className="bg-gradient-to-r from-[#6495ed] to-[#4169e1] text-white p-4 rounded-lg shadow-lg border border-white/20">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3 flex-1">
            <Smartphone className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <h3 className="font-semibold text-sm mb-1">
                Cüzdan App'inde Aç
              </h3>
              <p className="text-xs text-white/90 mb-3">
                MetaMask veya Trust Wallet'te daha sorunsuz çalışır.
              </p>
              <div className="flex space-x-2">
                <Button
                  onClick={handleOpenInWallet}
                  size="sm"
                  className="bg-white/20 hover:bg-white/30 text-white text-xs px-3 py-1 h-auto rounded"
                >
                  <ExternalLink className="w-3 h-3 mr-1" />
                  Cüzdan App'te Aç
                </Button>
                <Button
                  onClick={handleDismiss}
                  size="sm"
                  variant="ghost"
                  className="text-white/80 hover:text-white text-xs px-2 py-1 h-auto"
                >
                  Devam Et
                </Button>
              </div>
            </div>
          </div>
          <Button
            onClick={handleDismiss}
            size="sm"
            variant="ghost"
            className="text-white/80 hover:text-white p-1 h-auto ml-2"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}