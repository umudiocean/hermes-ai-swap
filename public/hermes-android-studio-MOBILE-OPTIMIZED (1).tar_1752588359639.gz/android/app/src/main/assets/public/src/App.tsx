import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import SwapPage from "@/pages/swap";
import ReferralPage from "@/pages/referral";

import Header from "@/components/Header";
import "./lib/i18n"; // Initialize i18n system

import AnimatedBanner from "@/components/AnimatedBanner";
import MobileBanner from "@/components/MobileBanner";
import MobileWalletOptimizer from "@/components/MobileWalletOptimizer";
import NotFound from "@/pages/not-found";
import { setupMobileWalletDetection } from "@/lib/mobileWallet";
import { useEffect } from "react";
import { useCapacitor } from "@/hooks/useCapacitor";

function Router() {
  return (
    <MobileWalletOptimizer>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
        <AnimatedBanner />
        <Header />
        <Switch>
          <Route path="/" component={SwapPage} />
          <Route path="/swap" component={SwapPage} />
          <Route path="/referral" component={ReferralPage} />

          <Route component={NotFound} />
        </Switch>
        
        {/* Mobile UX Enhancement Banner */}
        <MobileBanner />
      </div>
    </MobileWalletOptimizer>
  );
}

function App() {
  const { isNative, platform } = useCapacitor();

  useEffect(() => {
    // PancakeSwap-style auto mobile wallet detection
    setupMobileWalletDetection();
    
    // Log platform info for debugging
    console.log(`Running on ${platform}${isNative ? ' (native)' : ' (web)'}`);
  }, [isNative, platform]);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
